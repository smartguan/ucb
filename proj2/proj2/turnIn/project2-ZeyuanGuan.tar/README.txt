Student: Zeyuan Seth Guan


2. Challenges: 
  At first I implemented the RoutingUpdate packet only with entries that are 
changed. But then I found out it can't handle implicitly withdrawl so I rewrote every thing and then it works.

  The most confusing part was that 0-hop = 1-hop !!!


3. None

4. None
